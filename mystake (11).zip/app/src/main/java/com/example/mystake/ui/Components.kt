package com.example.mystake.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    title: String,
    onMenuClick: (() -> Unit)? = null,
    onBackClick: (() -> Unit)? = null
) {
    TopAppBar(
        title = { Text(title, fontWeight = FontWeight.Bold) },
        navigationIcon = {
            if (onMenuClick != null) {
                IconButton(onClick = onMenuClick, modifier = Modifier.testTag("menu_button")) {
                    Icon(Icons.Default.Menu, contentDescription = "Menu")
                }
            } else if (onBackClick != null) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("back_button")) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.background,
            titleContentColor = MaterialTheme.colorScheme.onBackground
        )
    )
}

@Composable
fun AppDrawer(
    currentRoute: String,
    navigateTo: (String) -> Unit,
    closeDrawer: () -> Unit,
    onBackupClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    ModalDrawerSheet(
        modifier = Modifier.width(300.dp),
        drawerContainerColor = MaterialTheme.colorScheme.surface
    ) {
        Spacer(Modifier.height(24.dp))
        Text(
            "MyStake",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp),
            color = MaterialTheme.colorScheme.primary
        )
        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))
        
        NavigationDrawerItem(
            label = { Text("Home") },
            selected = currentRoute == Screen.Home.route,
            onClick = { navigateTo(Screen.Home.route); closeDrawer() },
            icon = { Icon(Icons.Default.Home, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Working Accounts") },
            selected = currentRoute.startsWith("account_list/${Screen.AccountList.FILTER_WORKING}"),
            onClick = { navigateTo(Screen.AccountList.createRoute(Screen.AccountList.FILTER_WORKING)); closeDrawer() },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF4CAF50)) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Blocked Accounts") },
            selected = currentRoute.startsWith("account_list/${Screen.AccountList.FILTER_BLOCKED}"),
            onClick = { navigateTo(Screen.AccountList.createRoute(Screen.AccountList.FILTER_BLOCKED)); closeDrawer() },
            icon = { Icon(Icons.Default.Cancel, contentDescription = null, tint = Color(0xFFF44336)) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Add New Account") },
            selected = currentRoute == Screen.AddAccount.route,
            onClick = { navigateTo(Screen.AddAccount.route); closeDrawer() },
            icon = { Icon(Icons.Default.AddCircle, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Search Account") },
            selected = currentRoute == Screen.Search.route,
            onClick = { navigateTo(Screen.Search.route); closeDrawer() },
            icon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
        NavigationDrawerItem(
            label = { Text("Backup Data") },
            selected = false,
            onClick = { onBackupClick(); closeDrawer() },
            icon = { Icon(Icons.Default.CloudUpload, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Restore Data") },
            selected = false,
            onClick = { onRestoreClick(); closeDrawer() },
            icon = { Icon(Icons.Default.SettingsBackupRestore, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
        NavigationDrawerItem(
            label = { Text("Fast Add Accounts (Bulk)") },
            selected = currentRoute == Screen.FastAdd.route,
            onClick = { navigateTo(Screen.FastAdd.route); closeDrawer() },
            icon = { Icon(Icons.Default.Speed, contentDescription = null) },
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
        )
    }
}
