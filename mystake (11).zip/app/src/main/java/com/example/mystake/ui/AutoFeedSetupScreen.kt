package com.example.mystake.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.mystake.data.AccountEntity
import com.example.mystake.data.AccountStatus
import com.example.mystake.viewmodel.AccountViewModel
import kotlinx.coroutines.launch
import java.util.UUID

@Composable
fun AutoFeedSetupScreen(
    viewModel: AccountViewModel,
    onComplete: () -> Unit
) {
    var password by remember { mutableStateOf("") }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val rawEmails = listOf(
        "ishikajaat101@telegmail.com",
        "tarunayadav102@telegmail.com",
        "ravikumar103@telegmail.com",
        "sumitdeshmukh104@telegmail.com",
        "sandeeplamba105@telegmail.com",
        "saytampandey106@telegmail.com",
        "raajansingh107@telegmail.com",
        "nareshkandu108@telegmail.com",
        "deepaksharma109@telegmail.com",
        "nareshsharma110@telegmail.com",
        "deepaksharma111@telegmail.com",
        "niteshshrama112@telegmail.com",
        "niteshshrama113@telegmail.com",
        "arjunreddy113@telegmail.com",
        "vikramparsad114@telegmail.com",
        "karthikramesh115@telegmail.com",
        "adityakumar116@telegmail.com",
        "rohitrajan117@telegmail.com",
        "gopalkrishnan118@telegmail.com",
        "shankargowda119@telegmail.com",
        "madhavannair120@telegmail.com",
        "tejanaidu121@telegmail.com",
        "yuvannaidu123@telegmail.com",
        "ritwikdas224@telegmail.com",
        "anishsinha125@telegmail.com",
        "sureshmahto126@telegmail.com",
        "abc227@telegmail.com",
        "arindamsen127@telegmail.com",
        "debayanpal128@telegmail.com",
        "sohamnandi129@telegmail.com",
        "debashis130@telegmail.com",
        "biswajitdey131@telegmail.com",
        "sureshdas132@telegmail.com",
        "amitmahato133@telegmail.com",
        "abirmukherjee133@telegmail.com",
        "gambhirsingh134@telegmail.com",
        "sahilkumar135@telegmail.com",
        "vanyabatra135@telegmail.com",
        "mukeshkapoor136@telegmail.com",
        "preetihooda137@telegmail.com",
        "harishkumar138@telegmail.com",
        "rohitkhuwvat139@telegmail.com",
        "adhyagill140@telegmail.com",
        "myrakapoor141@telegmail.com",
        "rayansh142@telegmail.com",
        "navyakhan143@telegmail.com",
        "kiranvera144@telegmail.com",
        "monajseh145@telegmail.com",
        "deepakawa146@telegmail.com",
        "ausi147@telegmail.com",
        "inayachawla148@telegmail.com",
        "nahusou149@telegmail.com",
        "monijaou150@telegmail.com"
    )

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Auto-Feed Setup",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Found ${rawEmails.size} pre-loaded emails. Enter a common password to add them all into the app database.",
            style = MaterialTheme.typography.bodyLarge,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Common Password") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth()
        )
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = {
                if (password.isBlank()) {
                    Toast.makeText(context, "Please enter a password", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                
                coroutineScope.launch {
                    val time = System.currentTimeMillis()
                    var count = 0
                    
                    rawEmails.forEach { email ->
                        // Extract number from email prefix
                        val digits = email.substringBefore("@").filter { it.isDigit() }
                        if (digits.isNotEmpty()) {
                            val num = digits.toIntOrNull() ?: 0
                            val name = "Id-$num"
                            
                            // Check if blocked
                            val status = if (num in 101..116) AccountStatus.BLOCKED else AccountStatus.WORKING
                            
                            val account = AccountEntity(
                                id = UUID.randomUUID().toString(),
                                name = name,
                                loginId = email,
                                password = password,
                                note = "",
                                status = status,
                                createdDate = time,
                                lastUpdatedDate = time
                            )
                            viewModel.insertAccount(account)
                            count++
                        }
                    }
                    
                    val prefs = context.getSharedPreferences("mystake_prefs", Context.MODE_PRIVATE)
                    prefs.edit().putBoolean("is_auto_feed_done", true).apply()
                    
                    Toast.makeText(context, "$count accounts saved successfully!", Toast.LENGTH_LONG).show()
                    onComplete()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("Import & Save All")
        }
    }
}
