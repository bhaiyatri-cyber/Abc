package com.example.mystake.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.InputStreamReader
import java.io.OutputStreamWriter

class BackupManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("backup_prefs", Context.MODE_PRIVATE)
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val listType = Types.newParameterizedType(List::class.java, AccountEntity::class.java)
    private val adapter = moshi.adapter<List<AccountEntity>>(listType)

    fun getSavedBackupUri(): Uri? {
        val uriString = prefs.getString("backup_uri", null)
        return if (uriString != null) Uri.parse(uriString) else null
    }

    fun saveBackupUri(uri: Uri) {
        prefs.edit().putString("backup_uri", uri.toString()).apply()
        try {
            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, takeFlags)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun clearSavedUri() {
        prefs.edit().remove("backup_uri").apply()
    }

    suspend fun performBackup(uri: Uri, accounts: List<AccountEntity>): Boolean = withContext(Dispatchers.IO) {
        try {
            val json = adapter.toJson(accounts)
            context.contentResolver.openOutputStream(uri, "w")?.use { outputStream ->
                OutputStreamWriter(outputStream).use { writer ->
                    writer.write(json)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun performRestore(uri: Uri): List<AccountEntity>? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                InputStreamReader(inputStream).use { reader ->
                    val json = reader.readText()
                    adapter.fromJson(json)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
