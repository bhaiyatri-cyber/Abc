package com.example.mystake.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.mystake.data.AccountEntity
import com.example.mystake.data.AccountStatus
import com.example.mystake.viewmodel.AccountViewModel
import java.util.UUID

@Composable
fun FastAddScreen(
    viewModel: AccountViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    
    // Sticky fields
    var seriesPrefix by remember { mutableStateOf("") }
    var startNumber by remember { mutableStateOf("101") }
    var commonPassword by remember { mutableStateOf("") }
    var isWorking by remember { mutableStateOf(true) }
    var passwordVisible by remember { mutableStateOf(false) }

    // Fast-changing fields
    var currentEmail by remember { mutableStateOf("") }
    var currentNote by remember { mutableStateOf("") }
    
    val emailFocusRequester = remember { FocusRequester() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("Series & Common Data (Stays same)", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = seriesPrefix,
                onValueChange = { seriesPrefix = it },
                label = { Text("Prefix (e.g. Id-)") },
                modifier = Modifier.weight(1f),
                singleLine = true
            )
            OutlinedTextField(
                value = startNumber,
                onValueChange = { startNumber = it },
                label = { Text("Next Number") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
            )
        }
        Spacer(modifier = Modifier.height(8.dp))
        
        OutlinedTextField(
            value = commonPassword,
            onValueChange = { commonPassword = it },
            label = { Text("Common Password") },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(imageVector = image, contentDescription = "Toggle password")
                }
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        HorizontalDivider()
        Spacer(modifier = Modifier.height(16.dp))
        
        Text("Fast Entry", style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = currentEmail,
            onValueChange = { currentEmail = it },
            label = { Text("Email ID") },
            modifier = Modifier.fillMaxWidth().focusRequester(emailFocusRequester),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
        )
        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = currentNote,
            onValueChange = { currentNote = it },
            label = { Text("Note / Description (Optional)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(
                onDone = {
                    saveAccount(
                        context, viewModel, seriesPrefix, startNumber, commonPassword, currentEmail, currentNote, isWorking
                    ) { nextNum ->
                        startNumber = nextNum
                        currentEmail = ""
                        currentNote = ""
                        emailFocusRequester.requestFocus()
                    }
                }
            )
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = {
                saveAccount(
                    context, viewModel, seriesPrefix, startNumber, commonPassword, currentEmail, currentNote, isWorking
                ) { nextNum ->
                    startNumber = nextNum
                    currentEmail = ""
                    currentNote = ""
                    emailFocusRequester.requestFocus()
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) {
            Text("Save & Next")
        }
    }
}

private fun saveAccount(
    context: android.content.Context,
    viewModel: AccountViewModel,
    prefix: String,
    startNum: String,
    password: String,
    email: String,
    note: String,
    isWorking: Boolean,
    onSuccess: (String) -> Unit
) {
    if (startNum.isBlank() || email.isBlank() || password.isBlank()) {
        Toast.makeText(context, "Number, Email & Password are required", Toast.LENGTH_SHORT).show()
        return
    }
    
    val num = startNum.toIntOrNull()
    if (num == null) {
        Toast.makeText(context, "Start number must be a valid number", Toast.LENGTH_SHORT).show()
        return
    }
    
    val name = "$prefix$num"
    val status = if (isWorking) AccountStatus.WORKING else AccountStatus.BLOCKED
    val time = System.currentTimeMillis()
    
    val newAccount = AccountEntity(
        id = UUID.randomUUID().toString(),
        name = name.trim(),
        loginId = email.trim(),
        password = password,
        note = note.trim(),
        status = status,
        createdDate = time,
        lastUpdatedDate = time
    )
    
    viewModel.insertAccount(newAccount)
    Toast.makeText(context, "Saved $name!", Toast.LENGTH_SHORT).show()
    
    onSuccess((num + 1).toString())
}
