package com.example.util

import android.content.Context
import android.net.Uri
import com.example.data.local.AccountEntity
import com.example.data.local.SyncStatus
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader

object BackupRestoreUtil {
    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val type = Types.newParameterizedType(List::class.java, AccountEntity::class.java)
    private val adapter = moshi.adapter<List<AccountEntity>>(type)

    suspend fun exportToJson(context: Context, uri: Uri, accounts: List<AccountEntity>): Boolean = withContext(Dispatchers.IO) {
        try {
            val json = adapter.toJson(accounts)
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(json.toByteArray())
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun importFromJson(context: Context, uri: Uri): List<AccountEntity>? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val reader = BufferedReader(InputStreamReader(inputStream))
                val json = reader.readText()
                val accounts = adapter.fromJson(json)
                accounts?.map { it.copy(syncStatus = SyncStatus.PENDING_ADD, updatedAt = System.currentTimeMillis()) }
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
