package com.example.ui.account

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FastAddScreen(
    viewModel: AccountViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var rawText by remember { mutableStateOf("") }
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Fast Add / Bulk Add") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Format: Name, LoginID, Password (one per line)", style = MaterialTheme.typography.bodyMedium)
            
            OutlinedTextField(
                value = rawText,
                onValueChange = { rawText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                label = { Text("Paste accounts here") }
            )
            
            Button(
                onClick = {
                    val lines = rawText.lines().filter { it.isNotBlank() }
                    var added = 0
                    for (line in lines) {
                        val parts = line.split(",").map { it.trim() }
                        if (parts.size >= 3) {
                            viewModel.saveAccount(null, parts[0], parts[1], parts[2], "WORKING", "")
                            added++
                        }
                    }
                    Toast.makeText(context, "Added $added accounts", Toast.LENGTH_SHORT).show()
                    if (added > 0) onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Bulk Add Accounts")
            }
        }
    }
}
