package com.example.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.data.repository.AccountRepository
import com.example.ui.ViewModelFactory
import com.example.ui.account.AccountScreen
import com.example.ui.account.AccountViewModel
import com.example.ui.account.FastAddScreen
import com.example.ui.dashboard.DashboardScreen
import com.example.ui.dashboard.DashboardViewModel
import com.example.ui.login.LoginScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.settings.SettingsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object Routes {
    const val LOGIN = "login"
    const val DASHBOARD = "dashboard"
    const val ACCOUNT = "account/{accountId}"
    const val FAST_ADD = "fast_add"
    const val SETTINGS = "settings"
    
    fun accountRoute(accountId: String?) = accountId?.let { "account/$it" } ?: "account/new"
}

@Composable
fun NavGraph(
    navController: NavHostController,
    repository: AccountRepository,
    modifier: Modifier = Modifier
) {
    val factory = ViewModelFactory(repository)

    NavHost(
        navController = navController,
        startDestination = Routes.LOGIN,
        modifier = modifier
    ) {
        composable(Routes.LOGIN) {
            LoginScreen(
                onLoginSuccess = {
                    navController.navigate(Routes.DASHBOARD) {
                        popUpTo(Routes.LOGIN) { inclusive = true }
                    }
                }
            )
        }

        composable(Routes.DASHBOARD) {
            val viewModel: DashboardViewModel = viewModel(factory = factory)
            DashboardScreen(
                viewModel = viewModel,
                onNavigateToAccount = { accountId ->
                    navController.navigate(Routes.accountRoute(accountId))
                },
                onNavigateToSettings = {
                    navController.navigate(Routes.SETTINGS)
                },
                onNavigateToFastAdd = {
                    navController.navigate(Routes.FAST_ADD)
                }
            )
        }

        composable(Routes.ACCOUNT) { backStackEntry ->
            val accountId = backStackEntry.arguments?.getString("accountId")?.takeIf { it != "new" }
            val viewModel: AccountViewModel = viewModel(factory = factory)
            AccountScreen(
                viewModel = viewModel,
                accountId = accountId,
                onBack = { navController.navigateUp() }
            )
        }
        
        composable(Routes.FAST_ADD) {
            val viewModel: AccountViewModel = viewModel(factory = factory)
            FastAddScreen(
                viewModel = viewModel,
                onBack = { navController.navigateUp() }
            )
        }

        composable(Routes.SETTINGS) {
            val viewModel: SettingsViewModel = viewModel(factory = factory)
            val accountsProvider = {
                // simple block to fetch accounts synchronously for backup, or could be passed a different way
                // since we just need it for backup
                runBlocking { repository.allAccounts.first() }
            }
            SettingsScreen(
                viewModel = viewModel,
                accountsProvider = accountsProvider,
                onRestoreAccounts = { accounts ->
                    runBlocking {
                        accounts.forEach { repository.insertAccount(it) }
                    }
                },
                onBack = { navController.navigateUp() },
                onLogoutComplete = {
                    navController.navigate(Routes.LOGIN) {
                        popUpTo(0)
                    }
                }
            )
        }
    }
}
