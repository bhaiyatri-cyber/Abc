package com.example.ui.account

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountScreen(
    viewModel: AccountViewModel,
    accountId: String?,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    
    var isEditMode by remember { mutableStateOf(accountId == null) }
    var name by remember { mutableStateOf("") }
    var loginId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("WORKING") }
    var notes by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(accountId) {
        viewModel.loadAccount(accountId)
    }

    LaunchedEffect(uiState) {
        if (uiState is AccountUiState.Success) {
            val account = (uiState as AccountUiState.Success).account
            if (account != null && !isEditMode) {
                name = account.name
                loginId = account.loginId
                password = account.passwordEncrypted
                status = account.status
                notes = account.notes
            }
        }
    }

    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    fun copyToClipboard(text: String, label: String) {
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied", Toast.LENGTH_SHORT).show()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (accountId == null) "Add Account" else if (isEditMode) "Edit Account" else "Account Details") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (accountId != null && !isEditMode) {
                        IconButton(onClick = { isEditMode = true }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit")
                        }
                        IconButton(onClick = { showDeleteConfirm = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (uiState is AccountUiState.Loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (isEditMode) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Name (Platform/App)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = loginId,
                        onValueChange = { loginId = it },
                        label = { Text("Login ID / Email") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password") },
                        modifier = Modifier.fillMaxWidth(),
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        }
                    )
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Status: ")
                        Spacer(modifier = Modifier.width(8.dp))
                        FilterChip(
                            selected = status == "WORKING",
                            onClick = { status = "WORKING" },
                            label = { Text("WORKING") }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        FilterChip(
                            selected = status == "BLOCKED",
                            onClick = { status = "BLOCKED" },
                            label = { Text("BLOCKED") }
                        )
                    }

                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                    
                    Spacer(modifier = Modifier.weight(1f))
                    
                    Button(
                        onClick = {
                            if (name.isNotBlank()) {
                                viewModel.saveAccount(accountId, name, loginId, password, status, notes)
                                onBack()
                            } else {
                                Toast.makeText(context, "Name is required", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Save Account")
                    }
                } else {
                    // View Mode
                    val account = (uiState as AccountUiState.Success).account
                    if (account != null) {
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(account.name, style = MaterialTheme.typography.headlineSmall)
                                Divider()
                                
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Login ID", style = MaterialTheme.typography.labelSmall)
                                        Text(account.loginId, style = MaterialTheme.typography.bodyLarge)
                                    }
                                    IconButton(onClick = { copyToClipboard(account.loginId, "Login ID") }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Login ID")
                                    }
                                }
                                
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Password", style = MaterialTheme.typography.labelSmall)
                                        Text(
                                            if (showPassword) account.passwordEncrypted else "••••••••",
                                            style = MaterialTheme.typography.bodyLarge
                                        )
                                    }
                                    IconButton(onClick = { showPassword = !showPassword }) {
                                        Icon(
                                            if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                            contentDescription = "Toggle password"
                                        )
                                    }
                                    IconButton(onClick = { copyToClipboard(account.passwordEncrypted, "Password") }) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy Password")
                                    }
                                }
                                
                                Text("Status", style = MaterialTheme.typography.labelSmall)
                                Badge(containerColor = if (account.status == "WORKING") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) {
                                    Text(account.status, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                                
                                if (account.notes.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Notes", style = MaterialTheme.typography.labelSmall)
                                    Text(account.notes, style = MaterialTheme.typography.bodyMedium)
                                }
                                
                                Spacer(modifier = Modifier.height(16.dp))
                                val dateFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
                                Text("Created: ${dateFormat.format(Date(account.createdAt))}", style = MaterialTheme.typography.labelSmall)
                                Text("Updated: ${dateFormat.format(Date(account.updatedAt))}", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
        
        if (showDeleteConfirm) {
            AlertDialog(
                onDismissRequest = { showDeleteConfirm = false },
                title = { Text("Delete Account?") },
                text = { Text("This will permanently remove this account from local and cloud storage.") },
                confirmButton = {
                    TextButton(onClick = {
                        accountId?.let { viewModel.deleteAccount(it) }
                        showDeleteConfirm = false
                        onBack()
                    }) {
                        Text("Delete", color = MaterialTheme.colorScheme.error)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showDeleteConfirm = false }) {
                        Text("Cancel")
                    }
                }
            )
        }
    }
}
