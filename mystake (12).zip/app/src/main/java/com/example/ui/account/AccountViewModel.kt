package com.example.ui.account

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AccountEntity
import com.example.data.repository.AccountRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AccountViewModel(
    private val repository: AccountRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<AccountUiState>(AccountUiState.Loading)
    val uiState: StateFlow<AccountUiState> = _uiState.asStateFlow()

    fun loadAccount(id: String?) {
        if (id == null) {
            _uiState.value = AccountUiState.Success(null)
            return
        }
        viewModelScope.launch {
            repository.allAccounts.collect { accounts ->
                val account = accounts.find { it.id == id }
                _uiState.value = AccountUiState.Success(account)
            }
        }
    }

    fun saveAccount(
        id: String?,
        name: String,
        loginId: String,
        passwordEncrypted: String,
        status: String,
        notes: String
    ) {
        viewModelScope.launch {
            val timestamp = System.currentTimeMillis()
            if (id == null) {
                val newAccount = AccountEntity(
                    id = UUID.randomUUID().toString(),
                    name = name,
                    loginId = loginId,
                    passwordEncrypted = passwordEncrypted,
                    status = status,
                    notes = notes,
                    createdAt = timestamp,
                    updatedAt = timestamp
                )
                repository.insertAccount(newAccount)
            } else {
                val currentState = _uiState.value
                if (currentState is AccountUiState.Success && currentState.account != null) {
                    val updatedAccount = currentState.account.copy(
                        name = name,
                        loginId = loginId,
                        passwordEncrypted = passwordEncrypted,
                        status = status,
                        notes = notes,
                        updatedAt = timestamp
                    )
                    repository.updateAccount(updatedAccount)
                }
            }
        }
    }

    fun deleteAccount(id: String) {
        viewModelScope.launch {
            repository.markDeleted(id)
        }
    }
}

sealed class AccountUiState {
    object Loading : AccountUiState()
    data class Success(val account: AccountEntity?) : AccountUiState()
}
