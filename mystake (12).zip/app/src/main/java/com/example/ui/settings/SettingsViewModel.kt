package com.example.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.repository.AccountRepository
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(
    val repository: AccountRepository
) : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    
    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        _uiState.value = _uiState.value.copy(
            userEmail = auth.currentUser?.email ?: "Unknown User"
        )
    }

    fun manualSync() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSyncing = true, syncMessage = null)
            try {
                repository.syncAll()
                _uiState.value = _uiState.value.copy(isSyncing = false, syncMessage = "Sync completed successfully")
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(isSyncing = false, syncMessage = "Sync failed: ${e.message}")
            }
        }
    }

    fun logout(onLogoutComplete: () -> Unit) {
        viewModelScope.launch {
            auth.signOut()
            repository.clearLocalData()
            onLogoutComplete()
        }
    }
    
    fun clearSyncMessage() {
        _uiState.value = _uiState.value.copy(syncMessage = null)
    }
}

data class SettingsUiState(
    val userEmail: String = "",
    val isSyncing: Boolean = false,
    val syncMessage: String? = null
)
