package com.example.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AccountEntity
import com.example.data.repository.AccountRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DashboardViewModel(
    private val repository: AccountRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedTab = MutableStateFlow(Tab.ALL)
    val selectedTab = _selectedTab.asStateFlow()

    val uiState: StateFlow<DashboardUiState> = combine(
        repository.allAccounts,
        _searchQuery,
        _selectedTab
    ) { accounts, query, tab ->
        val filteredByQuery = if (query.isBlank()) {
            accounts
        } else {
            accounts.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.loginId.contains(query, ignoreCase = true)
            }
        }

        val filteredByTab = when (tab) {
            Tab.ALL -> filteredByQuery
            Tab.WORKING -> filteredByQuery.filter { it.status == "WORKING" }
            Tab.BLOCKED -> filteredByQuery.filter { it.status == "BLOCKED" }
        }

        DashboardUiState.Success(
            totalCount = accounts.size,
            workingCount = accounts.count { it.status == "WORKING" },
            blockedCount = accounts.count { it.status == "BLOCKED" },
            recentAccounts = filteredByTab.take(10), // Show latest 10 based on sort
            allFilteredAccounts = filteredByTab
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = DashboardUiState.Loading
    )

    init {
        viewModelScope.launch {
            repository.syncAll()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectTab(tab: Tab) {
        _selectedTab.value = tab
    }
    
    fun toggleAccountStatus(account: AccountEntity) {
        viewModelScope.launch {
            val newStatus = if (account.status == "WORKING") "BLOCKED" else "WORKING"
            repository.updateAccount(account.copy(status = newStatus))
        }
    }
}

enum class Tab {
    ALL, WORKING, BLOCKED
}

sealed class DashboardUiState {
    object Loading : DashboardUiState()
    data class Success(
        val totalCount: Int,
        val workingCount: Int,
        val blockedCount: Int,
        val recentAccounts: List<AccountEntity>,
        val allFilteredAccounts: List<AccountEntity>
    ) : DashboardUiState()
}
