package com.example.data.repository

import android.util.Log
import com.example.data.local.AccountDao
import com.example.data.local.AccountEntity
import com.example.data.local.SyncStatus
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class AccountRepository(
    private val accountDao: AccountDao,
    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val firebaseDatabase: FirebaseDatabase = FirebaseDatabase.getInstance()
) {
    val allAccounts: Flow<List<AccountEntity>> = accountDao.getAllAccounts()

    private val currentUserId: String?
        get() = firebaseAuth.currentUser?.uid

    private fun getAccountsRef() = currentUserId?.let { uid ->
        firebaseDatabase.getReference("users").child(uid).child("accounts")
    }

    suspend fun insertAccount(account: AccountEntity) {
        val pendingAccount = account.copy(syncStatus = SyncStatus.PENDING_ADD, updatedAt = System.currentTimeMillis())
        accountDao.insertAccount(pendingAccount)
        syncSingleAccount(pendingAccount)
    }

    suspend fun updateAccount(account: AccountEntity) {
        val pendingAccount = account.copy(syncStatus = SyncStatus.PENDING_UPDATE, updatedAt = System.currentTimeMillis())
        accountDao.updateAccount(pendingAccount)
        syncSingleAccount(pendingAccount)
    }

    suspend fun markDeleted(id: String) {
        val timestamp = System.currentTimeMillis()
        accountDao.markDeleted(id, timestamp)
        val account = accountDao.getAccountById(id)
        if (account != null) {
            syncSingleAccount(account)
        }
    }

    suspend fun syncSingleAccount(account: AccountEntity) = withContext(Dispatchers.IO) {
        val ref = getAccountsRef() ?: return@withContext
        try {
            if (account.isDeleted) {
                ref.child(account.id).removeValue().await()
                accountDao.deleteAccountHard(account.id)
            } else {
                ref.child(account.id).setValue(account.toMap()).await()
                accountDao.updateAccount(account.copy(syncStatus = SyncStatus.SYNCED))
            }
        } catch (e: Exception) {
            Log.e("AccountRepository", "Error syncing account: ${e.message}")
        }
    }

    suspend fun syncAll() = withContext(Dispatchers.IO) {
        val ref = getAccountsRef() ?: return@withContext
        try {
            // Push unsynced local changes first
            val unsynced = accountDao.getUnsyncedAccounts()
            unsynced.forEach { syncSingleAccount(it) }

            // Pull changes from Firebase
            val snapshot = ref.get().await()
            val remoteAccounts = mutableListOf<AccountEntity>()
            
            for (child in snapshot.children) {
                try {
                    val id = child.key ?: continue
                    val name = child.child("name").getValue(String::class.java) ?: ""
                    val loginId = child.child("loginId").getValue(String::class.java) ?: ""
                    val passwordEncrypted = child.child("passwordEncrypted").getValue(String::class.java) ?: ""
                    val status = child.child("status").getValue(String::class.java) ?: "WORKING"
                    val notes = child.child("notes").getValue(String::class.java) ?: ""
                    val createdAt = child.child("createdAt").getValue(Long::class.java) ?: 0L
                    val updatedAt = child.child("updatedAt").getValue(Long::class.java) ?: 0L
                    val isDeleted = child.child("isDeleted").getValue(Boolean::class.java) ?: false
                    
                    remoteAccounts.add(
                        AccountEntity(
                            id = id,
                            name = name,
                            loginId = loginId,
                            passwordEncrypted = passwordEncrypted,
                            status = status,
                            notes = notes,
                            createdAt = createdAt,
                            updatedAt = updatedAt,
                            isDeleted = isDeleted,
                            syncStatus = SyncStatus.SYNCED
                        )
                    )
                } catch (e: Exception) {
                    Log.e("AccountRepository", "Error parsing account: ${e.message}")
                }
            }

            // Merge local and remote
            remoteAccounts.forEach { remote ->
                val local = accountDao.getAccountById(remote.id)
                if (local == null) {
                    if (!remote.isDeleted) {
                        accountDao.insertAccount(remote)
                    }
                } else if (local.syncStatus == SyncStatus.SYNCED) {
                    if (remote.updatedAt > local.updatedAt) {
                        if (remote.isDeleted) {
                            accountDao.deleteAccountHard(remote.id)
                        } else {
                            accountDao.updateAccount(remote)
                        }
                    }
                }
                // If local is not synced, we already pushed it, so we can ignore remote or conflict resolution.
                // In a perfect system, we'd do true conflict resolution based on timestamp, but this is a simplified version.
                // Assuming local unsynced > remote synced.
            }
        } catch (e: Exception) {
            Log.e("AccountRepository", "Error during full sync: ${e.message}")
        }
    }
    
    suspend fun clearLocalData() {
        accountDao.deleteAll()
    }

    private fun AccountEntity.toMap(): Map<String, Any> {
        return mapOf(
            "id" to id,
            "name" to name,
            "loginId" to loginId,
            "passwordEncrypted" to passwordEncrypted,
            "status" to status,
            "notes" to notes,
            "createdAt" to createdAt,
            "updatedAt" to updatedAt,
            "isDeleted" to isDeleted
        )
    }
}
