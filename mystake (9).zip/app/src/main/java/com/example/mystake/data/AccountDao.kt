package com.example.mystake.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY lastUpdatedDate DESC")
    fun getAllAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE status = :status ORDER BY lastUpdatedDate DESC")
    fun getAccountsByStatus(status: AccountStatus): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts ORDER BY lastUpdatedDate DESC LIMIT :limit")
    fun getRecentAccounts(limit: Int): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE name LIKE '%' || :query || '%' OR loginId LIKE '%' || :query || '%' ORDER BY lastUpdatedDate DESC")
    fun searchAccounts(query: String): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id")
    fun getAccountById(id: String): Flow<AccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: AccountEntity)

    @Update
    suspend fun updateAccount(account: AccountEntity)

    @Delete
    suspend fun deleteAccount(account: AccountEntity)
}
