package com.example.mystake.ui

sealed class Screen(val route: String) {
    object Home : Screen("home")
    object AddAccount : Screen("add_account")
    object EditAccount : Screen("edit_account/{accountId}") {
        fun createRoute(accountId: String) = "edit_account/$accountId"
    }
    object AccountDetail : Screen("account_detail/{accountId}") {
        fun createRoute(accountId: String) = "account_detail/$accountId"
    }
    object AccountList : Screen("account_list/{filter}") {
        fun createRoute(filter: String) = "account_list/$filter"
        const val FILTER_WORKING = "working"
        const val FILTER_BLOCKED = "blocked"
        const val FILTER_ALL = "all"
    }
    object Search : Screen("search")
}
