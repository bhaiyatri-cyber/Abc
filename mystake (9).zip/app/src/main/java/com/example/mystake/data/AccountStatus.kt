package com.example.mystake.data

enum class AccountStatus {
    WORKING,
    BLOCKED
}
