package com.example.mystake.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.example.mystake.data.AccountEntity
import com.example.mystake.data.AccountStatus
import com.example.mystake.viewmodel.AccountViewModel
import java.util.UUID

@Composable
fun AddEditScreen(
    viewModel: AccountViewModel,
    accountId: String? = null,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var loginId by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var isWorking by remember { mutableStateOf(true) }
    var passwordVisible by remember { mutableStateOf(false) }

    var existingAccount by remember { mutableStateOf<AccountEntity?>(null) }

    LaunchedEffect(accountId) {
        if (accountId != null) {
            viewModel.getAccountById(accountId).collect { account ->
                if (account != null && existingAccount == null) {
                    existingAccount = account
                    name = account.name
                    loginId = account.loginId
                    password = account.password
                    note = account.note
                    isWorking = account.status == AccountStatus.WORKING
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Name / Account Alias") },
            modifier = Modifier.fillMaxWidth().testTag("input_name"),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = loginId,
            onValueChange = { loginId = it },
            label = { Text("Login ID / Email") },
            modifier = Modifier.fillMaxWidth().testTag("input_login"),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(imageVector = image, contentDescription = if (passwordVisible) "Hide password" else "Show password")
                }
            },
            modifier = Modifier.fillMaxWidth().testTag("input_password"),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("Note (Optional)") },
            modifier = Modifier.fillMaxWidth().height(100.dp).testTag("input_note")
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Status:", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = isWorking,
                    onClick = { isWorking = true }
                )
                Text("Working", modifier = Modifier.padding(end = 16.dp))
                
                RadioButton(
                    selected = !isWorking,
                    onClick = { isWorking = false }
                )
                Text("Blocked")
            }
        }
        
        Spacer(modifier = Modifier.height(32.dp))
        
        Button(
            onClick = {
                if (name.isBlank() || loginId.isBlank() || password.isBlank()) {
                    Toast.makeText(context, "Please fill required fields", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                
                val status = if (isWorking) AccountStatus.WORKING else AccountStatus.BLOCKED
                val time = System.currentTimeMillis()
                
                if (existingAccount != null) {
                    val updated = existingAccount!!.copy(
                        name = name.trim(),
                        loginId = loginId.trim(),
                        password = password,
                        note = note.trim(),
                        status = status,
                        lastUpdatedDate = time
                    )
                    viewModel.updateAccount(updated)
                    Toast.makeText(context, "Account updated", Toast.LENGTH_SHORT).show()
                } else {
                    val newAccount = AccountEntity(
                        id = UUID.randomUUID().toString(),
                        name = name.trim(),
                        loginId = loginId.trim(),
                        password = password,
                        note = note.trim(),
                        status = status,
                        createdDate = time,
                        lastUpdatedDate = time
                    )
                    viewModel.insertAccount(newAccount)
                    Toast.makeText(context, "Account saved successfully", Toast.LENGTH_SHORT).show()
                }
                onNavigateBack()
            },
            modifier = Modifier.fillMaxWidth().height(56.dp).testTag("save_button"),
            shape = MaterialTheme.shapes.medium
        ) {
            Text(if (accountId == null) "Save Account" else "Update Account", style = MaterialTheme.typography.titleMedium)
        }
    }
}
