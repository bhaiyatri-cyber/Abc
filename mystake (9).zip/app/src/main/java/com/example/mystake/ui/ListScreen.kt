package com.example.mystake.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.mystake.viewmodel.AccountViewModel

@Composable
fun ListScreen(
    viewModel: AccountViewModel,
    filter: String,
    onNavigateToDetail: (String) -> Unit
) {
    val accounts by when (filter) {
        Screen.AccountList.FILTER_WORKING -> viewModel.workingAccounts.collectAsStateWithLifecycle()
        Screen.AccountList.FILTER_BLOCKED -> viewModel.blockedAccounts.collectAsStateWithLifecycle()
        else -> viewModel.allAccounts.collectAsStateWithLifecycle()
    }

    if (accounts.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No accounts found.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(accounts) { account ->
                AccountItemCard(account = account, onClick = { onNavigateToDetail(account.id) })
            }
        }
    }
}
