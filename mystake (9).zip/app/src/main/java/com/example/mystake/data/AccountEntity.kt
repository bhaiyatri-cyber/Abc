package com.example.mystake.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val loginId: String,
    val password: String, // Ideally should be encrypted, but simple for now unless specified
    val status: AccountStatus,
    val note: String,
    val createdDate: Long,
    val lastUpdatedDate: Long
)
