package com.example.mystake.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystake.data.AccountEntity
import com.example.mystake.data.AccountRepository
import com.example.mystake.data.AccountStatus
import com.example.mystake.data.AppDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AccountViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: AccountRepository

    init {
        val accountDao = AppDatabase.getDatabase(application).accountDao()
        repository = AccountRepository(accountDao)
    }

    val allAccounts: StateFlow<List<AccountEntity>> = repository.allAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workingAccounts: StateFlow<List<AccountEntity>> = repository.workingAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val blockedAccounts: StateFlow<List<AccountEntity>> = repository.blockedAccounts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentAccounts: StateFlow<List<AccountEntity>> = repository.getRecentAccounts(5)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<AccountEntity>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isBlank()) {
                kotlinx.coroutines.flow.flowOf(emptyList())
            } else {
                repository.searchAccounts(query)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun getAccountById(id: String): Flow<AccountEntity?> {
        return repository.getAccountById(id)
    }

    fun insertAccount(account: AccountEntity) {
        viewModelScope.launch {
            repository.insert(account)
        }
    }

    fun updateAccount(account: AccountEntity) {
        viewModelScope.launch {
            repository.update(account.copy(lastUpdatedDate = System.currentTimeMillis()))
        }
    }

    fun deleteAccount(account: AccountEntity) {
        viewModelScope.launch {
            repository.delete(account)
        }
    }

    fun toggleAccountStatus(account: AccountEntity) {
        val newStatus = if (account.status == AccountStatus.WORKING) AccountStatus.BLOCKED else AccountStatus.WORKING
        updateAccount(account.copy(status = newStatus))
    }
}
