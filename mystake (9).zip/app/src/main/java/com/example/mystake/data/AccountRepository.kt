package com.example.mystake.data

import kotlinx.coroutines.flow.Flow

class AccountRepository(private val accountDao: AccountDao) {
    val allAccounts: Flow<List<AccountEntity>> = accountDao.getAllAccounts()
    val workingAccounts: Flow<List<AccountEntity>> = accountDao.getAccountsByStatus(AccountStatus.WORKING)
    val blockedAccounts: Flow<List<AccountEntity>> = accountDao.getAccountsByStatus(AccountStatus.BLOCKED)

    fun getRecentAccounts(limit: Int): Flow<List<AccountEntity>> = accountDao.getRecentAccounts(limit)
    
    fun searchAccounts(query: String): Flow<List<AccountEntity>> = accountDao.searchAccounts(query)
    
    fun getAccountById(id: String): Flow<AccountEntity?> = accountDao.getAccountById(id)

    suspend fun insert(account: AccountEntity) {
        accountDao.insertAccount(account)
    }

    suspend fun update(account: AccountEntity) {
        accountDao.updateAccount(account)
    }

    suspend fun delete(account: AccountEntity) {
        accountDao.deleteAccount(account)
    }
}
