package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryDark = Color(0xFF64B5F6)
val SecondaryDark = Color(0xFF81C784)
val TertiaryDark = Color(0xFFFFB74D)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2C2C2C)

val OnBackgroundDark = Color(0xFFE0E0E0)
val OnSurfaceDark = Color(0xFFE0E0E0)
val OnSurfaceVariantDark = Color(0xFFA0A0A0)
