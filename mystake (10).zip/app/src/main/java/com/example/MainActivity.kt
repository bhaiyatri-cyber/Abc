package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import com.example.mystake.ui.*
import com.example.mystake.viewmodel.AccountViewModel
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val viewModel: AccountViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MyStakeApp(viewModel)
            }
        }
    }
}

@Composable
fun MyStakeApp(viewModel: AccountViewModel) {
    val navController = rememberNavController()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Screen.Home.route

    val context = LocalContext.current
    
    val createDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            viewModel.saveBackupUri(uri)
            viewModel.backupData(uri,
                onSuccess = { Toast.makeText(context, "Backup saved successfully!", Toast.LENGTH_SHORT).show() },
                onError = { Toast.makeText(context, "Backup failed!", Toast.LENGTH_SHORT).show() }
            )
        }
    }

    val openDocumentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.restoreData(uri,
                onSuccess = { count -> Toast.makeText(context, "Restored $count accounts successfully", Toast.LENGTH_SHORT).show() },
                onError = { Toast.makeText(context, "Restore failed! Invalid file.", Toast.LENGTH_SHORT).show() }
            )
        }
    }

    val handleBackup = {
        val savedUri = viewModel.getSavedBackupUri()
        if (savedUri != null) {
            viewModel.backupData(savedUri,
                onSuccess = { Toast.makeText(context, "Backup updated successfully!", Toast.LENGTH_SHORT).show() },
                onError = {
                    viewModel.clearSavedUri()
                    createDocumentLauncher.launch("mystake_backup.json")
                }
            )
        } else {
            createDocumentLauncher.launch("mystake_backup.json")
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            AppDrawer(
                currentRoute = currentRoute,
                navigateTo = { route -> 
                    navController.navigate(route) {
                        popUpTo(Screen.Home.route) { saveState = true }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                closeDrawer = { scope.launch { drawerState.close() } },
                onBackupClick = handleBackup,
                onRestoreClick = { openDocumentLauncher.launch(arrayOf("application/json", "*/*")) }
            )
        }
    ) {
        val title = when {
            currentRoute == Screen.Home.route -> "MyStake"
            currentRoute == Screen.AddAccount.route -> "Add Account"
            currentRoute == Screen.FastAdd.route -> "Fast Add Accounts"
            currentRoute.startsWith("edit_account") -> "Edit Account"
            currentRoute.startsWith("account_detail") -> "Account Detail"
            currentRoute == Screen.Search.route -> "Search"
            currentRoute.startsWith("account_list/${Screen.AccountList.FILTER_WORKING}") -> "Working Accounts"
            currentRoute.startsWith("account_list/${Screen.AccountList.FILTER_BLOCKED}") -> "Blocked Accounts"
            else -> "MyStake"
        }

        val showMenu = currentRoute == Screen.Home.route

        Scaffold(
            topBar = {
                AppTopBar(
                    title = title,
                    onMenuClick = if (showMenu) { { scope.launch { drawerState.open() } } } else null,
                    onBackClick = if (!showMenu) { { navController.navigateUp() } } else null
                )
            },
            modifier = Modifier.fillMaxSize()
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier.padding(innerPadding)
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToWorking = { navController.navigate(Screen.AccountList.createRoute(Screen.AccountList.FILTER_WORKING)) },
                        onNavigateToBlocked = { navController.navigate(Screen.AccountList.createRoute(Screen.AccountList.FILTER_BLOCKED)) },
                        onNavigateToAdd = { navController.navigate(Screen.AddAccount.route) },
                        onNavigateToSearch = { navController.navigate(Screen.Search.route) },
                        onNavigateToDetail = { id -> navController.navigate(Screen.AccountDetail.createRoute(id)) }
                    )
                }
                
                composable(Screen.AddAccount.route) {
                    AddEditScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.navigateUp() }
                    )
                }
                
                composable(Screen.FastAdd.route) {
                    FastAddScreen(
                        viewModel = viewModel,
                        onNavigateBack = { navController.navigateUp() }
                    )
                }
                
                composable(
                    route = Screen.EditAccount.route,
                    arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val accountId = backStackEntry.arguments?.getString("accountId")
                    AddEditScreen(
                        viewModel = viewModel,
                        accountId = accountId,
                        onNavigateBack = { navController.navigateUp() }
                    )
                }
                
                composable(
                    route = Screen.AccountDetail.route,
                    arguments = listOf(navArgument("accountId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val accountId = backStackEntry.arguments?.getString("accountId")
                    if (accountId != null) {
                        DetailScreen(
                            viewModel = viewModel,
                            accountId = accountId,
                            onNavigateToEdit = { id -> navController.navigate(Screen.EditAccount.createRoute(id)) },
                            onNavigateBack = { navController.navigateUp() }
                        )
                    }
                }
                
                composable(
                    route = Screen.AccountList.route,
                    arguments = listOf(navArgument("filter") { type = NavType.StringType })
                ) { backStackEntry ->
                    val filter = backStackEntry.arguments?.getString("filter") ?: Screen.AccountList.FILTER_ALL
                    ListScreen(
                        viewModel = viewModel,
                        filter = filter,
                        onNavigateToDetail = { id -> navController.navigate(Screen.AccountDetail.createRoute(id)) }
                    )
                }
                
                composable(Screen.Search.route) {
                    SearchScreen(
                        viewModel = viewModel,
                        onNavigateToDetail = { id -> navController.navigate(Screen.AccountDetail.createRoute(id)) }
                    )
                }
            }
        }
    }
}
